Contributors
============

Freek Dijkstra (macfreek)
G. Nicholas d'Andrea (gnidan)
Jeffrey Lo (jeffrey_lo)
Matthew Planchard (mplanchard)
Nicola Musatti (nmusatti)
David Fritzsche (davidfritzsche)
